# Weather App - DevOps Homework

## Overview  
This project is a simple Flask-based weather application that fetches weather data from OpenWeather API and stores it in a PostgreSQL database. Your task is to deploy this application and ensure it runs correctly in a production-like environment.

## Requirements  
- Python 3.8+  
- Flask  
- PostgreSQL  
- Requests  
- psycopg2  

## Installation and Setup  

1. **Clone the repository:**  
   ```sh
   git clone <repository_url>
   cd <repository_folder>
   ```

2. **Create and activate a virtual environment:**  
   ```sh
   python3 -m venv venv
   source venv/bin/activate  # On Windows use `venv\Scripts\activate`
   ```

3. **Install dependencies:**  
   ```sh
   pip install -r requirements.txt
   ```

4. **Set up the environment variables:**  
   ```sh
   export DATABASE_URL="your_postgresql_connection_string"
   export FLASK_APP=app.py
   export FLASK_ENV=production
   ```

5. **Run the application:**  
   ```sh
   python app.py
   ```

## Testing the Application  
- Open `http://localhost:8081` in your browser.  
- Check the `/ping` and `/health` endpoints.  
- Verify weather data is being stored in the database.  

## Submission  
Submit your deployment process documentation, configuration files, and any necessary setup instructions in a GitHub repository or as a compressed archive.  

Good luck!

